<?php

namespace App\Name;

use Illuminate\Database\Eloquent\Model;

class title extends Model
{
    //
}
